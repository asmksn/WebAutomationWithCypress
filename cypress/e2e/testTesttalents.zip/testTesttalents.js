/// <reference types="cypress" />

const { getLocaleDateFormat } = require("@angular/common")

describe('Automating Login and Registration Process', () => {
    
    it('TC1: registration', () =>{
        cy.visit('/')
        cy.get('Registration').click()
        cy.get('firstname').type('Test')
        cy.get('lastname').type('Talents')
        cy.get('username').type('testtalents')
        cy.get('email').type('testtalents@testtalents.com')
        cy.get('password').type('talents1')
        cy.get('re-type-password').type('talents1')
        cy.get('Sign up').click()
        
        cy.should('contains','welcome to testtalents, check your dashboard')
    })
    it('TC2: login', () =>{
        cy.visit('/')
        cy.get('username').type('testtalents')
        cy.get('password').type('talents1')
        cy.get('Login').click()
        cy.should('contains','welcome to testtalents, check your dashboard')
    })
})